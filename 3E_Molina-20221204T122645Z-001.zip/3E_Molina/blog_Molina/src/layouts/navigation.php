<nav class="container">
    <div id="logo">
        <a href="/">
            <img src="img/logo.png" alt="Blog logo" width="100%">
        </a>
    </div>
    <ul id="menu">
        <li>
            <a href="#">Browse blogs</a>
        </li>
        <li>
            <a href="login.php" class="btn btn-lg btn-rounded"> Login</a>
        </li>
    </ul>
</nav>